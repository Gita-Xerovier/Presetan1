package id.ac.umn.presetan.Interface;

import com.zomato.photofilters.imageprocessors.Filter;

public interface FiltersListFragmentListener {
    void onFilterSelected(Filter filter);
}
